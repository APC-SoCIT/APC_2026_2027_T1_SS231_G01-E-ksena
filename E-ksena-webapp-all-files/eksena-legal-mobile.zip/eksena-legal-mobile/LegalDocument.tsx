import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, LayoutChangeEvent } from 'react-native';
import type { LegalDocumentContent } from './legal-content';

/**
 * Renders a legal document from the shared content file.
 *
 * Deliberately plain React Native: no navigation library, no path aliases and
 * no theme import, so it drops into the mobile app without pulling anything
 * else along. Restyle it to match the app -- but do not edit the wording here,
 * because the wording lives in legal-content.ts and is shared with the web
 * dashboard.
 *
 * Twelve sections of continuous prose is how a policy goes unread, so there is
 * an index to jump from, numbered markers to keep your place, and a callout on
 * the clauses a reader is harmed by missing.
 *
 * Pass onBack to show a back control; leave it out if the screen already has a
 * header with one.
 */
export function LegalDocument({
  title,
  effectiveDate,
  intro,
  sections,
  onBack,
}: LegalDocumentContent & { onBack?: () => void }) {
  const scrollRef = useRef<ScrollView | null>(null);
  const sectionTops = useRef<Record<number, number>>({});
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const jumpTo = (index: number) => {
    const y = sectionTops.current[index];
    if (y === undefined) return;
    scrollRef.current?.scrollTo({ y: Math.max(y - 16, 0), animated: true });
    setActiveIndex(index);
  };

  const measureSection = (index: number) => (event: LayoutChangeEvent) => {
    sectionTops.current[index] = event.nativeEvent.layout.y;
  };

  return (
    <ScrollView ref={scrollRef} contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.datePill}>
        <Text style={styles.dateText}>Effective {effectiveDate}</Text>
      </View>

      <Text style={styles.intro}>{intro}</Text>

      <View style={styles.divider} />

      <Text style={styles.tocLabel}>ON THIS PAGE</Text>
      {sections.map((section, index) => (
        <Pressable key={section.heading} onPress={() => jumpTo(index)} hitSlop={4} style={styles.tocRow}>
          <Text style={styles.tocNumber}>{index + 1}</Text>
          <Text style={[styles.tocText, activeIndex === index && styles.tocTextActive]} numberOfLines={2}>
            {section.heading}
          </Text>
        </Pressable>
      ))}

      <View style={styles.divider} />

      {sections.map((section, index) => (
        <View
          key={section.heading}
          onLayout={measureSection(index)}
          style={[styles.section, section.emphasis && styles.sectionCallout]}
        >
          <View style={styles.headingRow}>
            <View style={[styles.badge, section.emphasis && styles.badgeCallout]}>
              <Text style={[styles.badgeText, section.emphasis && styles.badgeTextCallout]}>
                {index + 1}
              </Text>
            </View>
            <Text style={styles.heading}>{section.heading}</Text>
          </View>

          {section.paragraphs?.map((paragraph) => (
            <Text key={paragraph} style={styles.paragraph}>
              {paragraph}
            </Text>
          ))}

          {section.bullets?.map((bullet) => (
            <View key={bullet} style={styles.bulletRow}>
              <View style={styles.bulletDot} />
              <Text style={styles.bulletText}>{bullet}</Text>
            </View>
          ))}
        </View>
      ))}

      {onBack ? (
        <Pressable onPress={onBack} hitSlop={8} style={styles.backBtn}>
          <Text style={styles.backText}>Back</Text>
        </Pressable>
      ) : null}
    </ScrollView>
  );
}

const BRAND_RED = '#9B1C1C';
const TEXT_PRIMARY = '#1A1A1A';
const TEXT_SECONDARY = '#6B7280';
const BORDER = '#E5E7EB';
const OFF_WHITE = '#F7F7F8';
const DANGER_BG = '#FEF2F2';
const DANGER_BORDER = '#FCA5A5';

const styles = StyleSheet.create({
  scroll: { padding: 20, paddingBottom: 48, backgroundColor: '#FFFFFF' },
  title: { fontSize: 24, fontWeight: '700', color: TEXT_PRIMARY, marginBottom: 8 },
  datePill: {
    alignSelf: 'flex-start',
    backgroundColor: OFF_WHITE,
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 6,
    paddingVertical: 3,
    paddingHorizontal: 8,
    marginBottom: 16,
  },
  dateText: { fontSize: 12, fontWeight: '600', color: TEXT_SECONDARY },
  intro: { fontSize: 15, color: TEXT_PRIMARY, lineHeight: 26 },
  divider: { height: 1, backgroundColor: BORDER, marginVertical: 20 },
  tocLabel: { fontSize: 11, fontWeight: '700', letterSpacing: 0.8, color: TEXT_SECONDARY, marginBottom: 8 },
  tocRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, paddingVertical: 5 },
  tocNumber: { fontSize: 12, fontWeight: '700', color: BRAND_RED, minWidth: 16, lineHeight: 20 },
  tocText: { flex: 1, fontSize: 14, color: TEXT_SECONDARY, lineHeight: 20 },
  tocTextActive: { color: BRAND_RED, fontWeight: '600' },
  section: { marginBottom: 20 },
  sectionCallout: {
    backgroundColor: DANGER_BG,
    borderWidth: 1,
    borderColor: DANGER_BORDER,
    borderLeftWidth: 3,
    borderLeftColor: BRAND_RED,
    borderRadius: 8,
    padding: 12,
  },
  headingRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  badge: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: OFF_WHITE,
    borderWidth: 1,
    borderColor: BORDER,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeCallout: { backgroundColor: BRAND_RED, borderColor: BRAND_RED },
  badgeText: { fontSize: 11, fontWeight: '700', color: TEXT_SECONDARY },
  badgeTextCallout: { color: '#FFFFFF' },
  heading: { flex: 1, fontSize: 15, fontWeight: '700', color: TEXT_PRIMARY },
  paragraph: { fontSize: 14, color: TEXT_PRIMARY, lineHeight: 23, marginBottom: 8 },
  bulletRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 4, paddingLeft: 4 },
  bulletDot: { width: 5, height: 5, borderRadius: 2.5, backgroundColor: BRAND_RED, marginTop: 9 },
  bulletText: { flex: 1, fontSize: 14, color: TEXT_PRIMARY, lineHeight: 23 },
  backBtn: {
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginTop: 8,
  },
  backText: { fontSize: 14, fontWeight: '600', color: BRAND_RED },
});
